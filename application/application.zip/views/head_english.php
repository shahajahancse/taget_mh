<div align="center" style=" font-family: 'Times New Roman', Times, serif; width:100%;"><span style="font-size:18px; font-weight:bold;"><?php echo $company_name_english = $this->common_model->company_information("company_name_english"); ?></span><br />
<span class="style1" style="font-size:13px; font-weight:bold;"><?php echo $company_add_english = $this->common_model->company_information("company_add_english"); ?></span><br />
  <!--<span class="style1" style="font-size:13px; font-weight:bold;">Corporate Office : 8813 NW 23 Street, Miami, FL 33172, USA. </span>--></div>
 
