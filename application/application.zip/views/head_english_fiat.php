
<div align="center" style=" margin:0 auto;  overflow:hidden; font-family: 'Times New Roman', Times, serif;"><span style="font-size:18px; font-weight:bold;">Fiat Fashion Ltd.</span><br />
<span class="style1" style="font-size:13px; font-weight:bold;">878-879 Sharifpur, National University, Gazipur Sadar, Bangladesh. </span><br />
  <span class="style1" style="font-size:13px; font-weight:bold;"></span></div>
 
