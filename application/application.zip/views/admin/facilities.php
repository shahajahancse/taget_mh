<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

</head>

<body>
<div >

<div>
<div style="float:left; width: 400px; height:auto;"><h3>READING FACILITIES :</h3>
<p style=" text-align:justify;">The entire Ground and 1st floor of the library is dedicated for individual study and group discussion of the students. Multiple copies of different text books are available in the counter. The students can issue books on production of ID card and library card from the counter and use these within the library and are not eligible for check out. Approximately 200 students can use these facilities at a time. There is also provision for 60 individual study of researchers, faculty members and post-graduate students in the first floor.</p>
<h3>AIR CONDITIONED ROOM:</h3>
<p style="text-align:justify;">The library is fully central air conditioned. So the students can study here and feel ease.</p>
<h3>NEWSPAPERS AND MAGAZINES: </h3>
<p style="text-align:justify;">The daily newspapers are available here. There are also some monthly magazines here. So the students get the chance to read these.</p></div>
<div style="float:right; width:250px;"><img src="image/facilities.jpeg" /></div>
</div>

</div>

</body>

</html>
