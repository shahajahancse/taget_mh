<html>
<head>
</head>
<body>

<h3>Member profile submitted successfully!</h3>


<p><?php echo anchor('admin/member', 'Add another member!'); ?></p>

</body>
</html>