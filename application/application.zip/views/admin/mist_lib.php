<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<br />
<div  style="padding:10px;">
<h2>Central Library</h2>
<div>
<div style="float:left; width: 300px; height:auto;"><p style="text-align:justify;">The MIST Central Library has its own separate building approximately 20,000 square feet in space and is in close vicinity to the other academic buildings. The library hosts a vast and diverse collection of books, journals, monograms and periodicals of academic interest. It also includes a free internet browsing facility to facilitate research and academic activities of students and faculty members.</p></div>
<div style="float:right; width:250px;"><img src="image/library_home.jpg" /></div>
</div>

</div>

</body>

</html>
