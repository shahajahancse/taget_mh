<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<div >
<h2>Operating Hours</h2>
<div>
<div style="float:left; width: 300px; height:auto;"><p style="text-align:justify;">
<h3>Opening Time: &nbsp;&nbsp;&nbsp;9:00am</h3>
<h3>Closing Time: &nbsp;&nbsp;&nbsp;5:00pm </h3>
<p>In every closing date of University, Library is also closed</p>
</p></div>
<div style="float:right; width:250px;"><img src="image/Operating_hour.jpeg" /></div>
</div>

</div>

</body>

</html>

