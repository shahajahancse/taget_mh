<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<div >
<h2>Rules & Regulation</h2>
<div>
<div style="float:left; width: 300px; height:auto;"><p style="text-align:justify;">The University Library is the most important common resource centre in Link�ping University, and it is primarily intended for use in academic research and university studies. Its role is to offer:
<ul>
     <li>Information services as well as a stock of books and periodicals of high quality</li>
     <li>An effective digital network</li>
     <li>Access to sources of information in both printed and electronic form</li>
     <li>A creative and stimulating environment for studies</li>
	 <li>The Library Card</li>
	
	 <ul>
</p></div>
<div style="float:right; width:250px;"><img src="image/rule_law.jpeg" /></div>
</div>

</div>

</body>

</html>

